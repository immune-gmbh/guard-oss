==============================
Contact Name: Kai Michaelis
Company Name: immue GmbH
Email: kai.michaelis@immu.ne
Phone: +491733503890
==============================

Serial Numbers:
J101WYR1

To download the TSCVerifyUtil Version 3.02.1.0005, go here:
https://tsc.intel.com/lenovo-dcg/tsc-verify/

The TSC Verify Utility requires the following Linux application:

nvme-cli-1.8.1-3.el7.x86_64.rpm	- Required for for nVME drive support
ncurses-compat-libs-6.1-7.20180224.el8.x86_64.rpm - Required for the TUI User Interface
nVidia Graphics Drive - Required to support systems with nVidia GPUs/


==============================
This software is subject to the U.S. Export Administration Regulations 
and other U.S. law, and may not be exported or re-exported to certain 
countries (Cuba, Iran, Crimea Region of Ukraine, North Korea, Sudan, 
and Syria) or to persons or entities prohibited from receiving U.S. 
exports (including Denied Parties, Specially Designated Nationals, and 
entities on the Bureau of Export Administration Entity List or involved 
with missile technology or nuclear, chemical or biological weapons).
==============================

tsc_lenovo-dcg_ver_3_02_0005a-readme.txt